﻿class Program
{
    public Program()
    {
    }

    static void Main()
    {
        AudioPlayer player = new AudioPlayer();
        player.PlayGreeting();

        SeccBot bot = new SeccBot();
        bot.StartChat();
    }
}