﻿using System;
using System.IO;
using System.Media;

public class AudioPlayer
{
    public void PlayGreeting()
    {
        string path = "greeting.wav";

        if (File.Exists(path))
        {
            SoundPlayer player = new SoundPlayer(path);
            player.PlaySync();
        }
        else
        {
            Console.WriteLine("Audio file not found. Skipping voice greeting.");
        }
    }
}